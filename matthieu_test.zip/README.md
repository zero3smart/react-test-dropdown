# Invertible

---------------------

## Installations

---------------------

You’ll need to have Node >= 6.9.5 on your machine. You can use nvm to easily switch Node versions between different projects.

#### Clone the repository
```bash
git clone https://gitlab.com/xininvert/UI.git
cd [directory]
npm install
npm run server
```
